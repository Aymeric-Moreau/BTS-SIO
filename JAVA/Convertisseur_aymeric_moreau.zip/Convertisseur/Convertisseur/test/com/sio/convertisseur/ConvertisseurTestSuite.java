/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sio.convertisseur;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 *
 * @author aymer
 */

@RunWith(Suite.class)
@SuiteClasses({ConvertisseurBasiqueIT.class, DeviseIT.class, ConvertisseurIT.class})
public class ConvertisseurTestSuite {
    
    
}
