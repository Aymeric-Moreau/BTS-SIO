/*
 * aymeric moreau
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cnc;

import com.sio.cnc.Commune;
import com.sio.cnc.Cooperateur;
import com.sio.cnc.Parcelle;

/**
 *
 * @author bc
 */
public class Cnc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Déclaration des variables d'instances
        Commune commune1;
        Parcelle parcelle;
        Cooperateur cooperateur1;

        //instanciation d'un objet de type Commune
        commune1 = new Commune("37150", "Dizy", 0.8);
        
        
        //Instanciation d'un objet de type Cooperateur
        cooperateur1 = new Cooperateur("Boivin", commune1);
        
        //instanciation et ajout d'un objet de type Parcelle
        parcelle = new Parcelle(1, 2, 1000);
        cooperateur1.addParcelle(parcelle);

        //instanciation d'un nouvel objet de type Parcelle avec le même numéro
        parcelle = new Parcelle(1, 2, 1000);
        
        //affichage de la valeur retournée par la méthode existeParcelle        
        logger.log(cooperateur1.existeParcelle(parcelle));

    }

}
