<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('AccueilController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404override();


$routes->get('/', 'AccueilController::index');

$routes->get('login', 'AccueilController::login');
$routes->get('logout', 'AccueilController::logout');
$routes->get('accueil', 'AccueilController');
$routes->get('RechercheClient', 'RechercheClientController::index');
$routes->post('connexion','ConnexionController::index');
$routes->post('listeDepartement', '\ajax\AjaxRechercheClientController::utilisateursPrivilege', ['filter' => 'auth']);