<?php 

namespace App\Controllers\entrainement\ajax;

use CodeIgniter\Controller;

/**
 * Controleur qui va gérer les action ajax d'un utilisateur
 */

class AjaxRechercheClientController extends Controller{
    /**
     * demande au modéle UtilisateurModel d'executer la fonction
     * getUtilisateurPrivilege() avec le privilege reçu en POST
     * encode en JSON les données récupérée
     */

public function departementsPays() {
    $m_departement = model('App\Models\DepartementModel');
    $pays = $this->request->getVar('lepays');
    $data = $m_departement->getUtilisateursPrivilege($privilege);
    
    echo json_encode($data);
    }
}