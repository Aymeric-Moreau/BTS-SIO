<?php

namespace App\Controllers;

class RechercheClientController extends BaseController {

    public function index() {

        
        $PaysModel = model('App\Models\PaysModel');

        $data['pays'] = $PaysModel->getPays();

        $DepartementModel = model('App\Models\DepartementModel');
        

        $data['departement'] = $DepartementModel->getDepartement();


        echo view('pages/v_recherche_par_client', $data);
    }

}
