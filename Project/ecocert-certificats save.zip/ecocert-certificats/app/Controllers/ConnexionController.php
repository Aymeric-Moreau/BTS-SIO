<?php

namespace App\Controllers;

class ConnexionController extends BaseController {

    public function index() {
        //on récupère les données saisies
        $login = $this->request->getVar('login');
        $mdp = $this->request->getvar('mdp');

        //on crée une instance pour le modèle m_utilisateur
        $m_utilisateur = model('App\Models\UtilisateurModel');

        //on appelle la méthode du modèle pour récupérer l'utilisateur
        $result = $m_utilisateur->getUtilisateur($login, $mdp);

        //si la requête renvoie une ligne
        if ($result) {
            //on ajoute le nom, le prénom de l'utilisateur
            // dans les données de la session
            $connexiondata = [
                'username' => $result[0]->nomUtilisateur,
                'prenom' => $result[0]->prenomUtilisateur,
                'isLoggedIn' => true,
            ];
            session()->set($connexiondata);

            //l'utilisateur est redirigé vers la page d'accueil
            return redirect()->to('accueil');
        } else {
            //cas où l'utilisateur n'a pas été trouvé
            $data['titre'] = "Erreur de connexion ! Modifiez vos informations de connexion";
            echo view('pages/v_connexion', $data);
        }
    }

}
