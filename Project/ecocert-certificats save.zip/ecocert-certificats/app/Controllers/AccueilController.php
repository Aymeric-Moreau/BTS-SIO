<?php

namespace App\Controllers;

class AccueilController extends BaseController {
    
    public function index() {
        echo view('pages/v_accueil');
    }
    
    /*
     * affiche la page de connexion
     */
    public function login() {
        //défini les données à envoyer à la vue en l'occurence le titre
        $data['titre'] = "Connexion Espace Utilisateur";
        //charge la vue en passant des données en paramètres
        return view('pages/v_connexion', $data);
    }
    
    /*
     * déconnecte l'utilisateur et redirige sur la page d'accueil
     */
    public function logout() {
        //détruit la session
        session()->destroy();
        return redirect()->to('accueil');
    }
}

