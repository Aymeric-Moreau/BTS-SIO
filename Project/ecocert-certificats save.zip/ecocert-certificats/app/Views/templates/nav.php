<body>
    <nav class="navbar navbar-expand-lg bg-light navbar-light">
        <div class="container">
            <?php
            $imageProperties = [
                'src' => img_url('ecocert.png'),
                'alt' => 'image logo ecocert',
                'class' => 'img-thumbnail',
                'width' => '153',
                'height' => '75',
                'title' => 'logo ecocert-certificats',
            ];
            ?>
            <a class="navbar-brand" href="<?php site_url('accueil'); ?>"><?php echo img($imageProperties); ?> </a>
            <!-- gestion du menu pour les supports mobiles -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#menu-sio">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </li>
            </ul>
            <!-- Fin gestion menu support mobile -->
            <!-- liste des événements du menu -->
            <?php 
            if (!session()->get('isLoggedIn')) {
                ?>
                <div class="collapse navbar-collapse" id="menu-sio">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a href="<?php echo site_url('login'); ?>"><span class="bi-person-fill"> se connecter</span> </a>
                        </li>
                    </ul>
                </div>
                <?php
            } else {
                ?>
            <div class="collapse navbar-collapse" id="menu-sio">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        
                        <a href="<?php echo site_url('RechercheClient'); ?>"><span class="bi-person-fill">Recherche par client</span> </a>
                    </li>
                    <li class="nav-item">
                        <?php echo session()->get('prenom') . ' ' . session()->get('username') ?>
                        <a href="<?php echo site_url('logout'); ?>"><span class="bi-person-fill">se déconnecter</span> </a>
                    </li>
                </ul>
            </div>
            <?php
            }
            ?>
        </div>
    </nav>
</body>