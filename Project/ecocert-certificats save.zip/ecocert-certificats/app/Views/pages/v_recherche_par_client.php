<div class="container">
    <!-- affiche le titre reçu -->
    <h1>titre</h1>

    <?php
    $attributes = ["id" => "userform", "name" => "userform"];
    // Ajout du formulaire avec indication de l'action lors du submit

    echo form_open('connexion', $attributes);
    ?>

    <div class="mb-3 col-md-3">
        <?php
        // création du tableau des attributs des labels
        $att_label = [
            'class' => 'form-label'
        ];
        echo form_label('NOM / RAISON SOCIAL', 'nom', $att_label);

        // Création du tableau des attributs du champ 
        $data_nom = [
            'class' => 'form-control',
            'name' => 'nom',
            'id' => 'nom',
            'type' => 'text',
            'placeholder' => '',
            // à la validation du formulaire, si celui-ci n'est pas valide,
            // si le champ était rempli,
            // la saisie du nom sera toujours présente
            'value' => set_value('nom')
        ];
        // Ajout d cahmp input 'NOM' au formulaire
        echo form_input($data_nom);
        ?>
    </div>
    <div class="mb-3 col-md-3">
        <?php
        echo form_label('Pays :', 'pays', $att_label);

        $attrib_select = array(
            'class' => 'form-control',
            'id' => 'listePays',
        );
        $options = array();

        foreach ($pays as $pay) {
            $options[$pay->id] = $pay->nom_pays;
        }

        echo form_dropdown('pays', $options, '1', $attrib_select);
        ?>
    </div>


    <div class="mb-3 col-md-3">
        <?php
        echo form_label('Département', 'departement', $att_label);

        $attrib_select = array(
            'class' => 'form-control',
            'id' => 'listeDepartement',
            'disabled' => 'disabled' // désactive de base l'input
        );
        $options = array();
        $options[-1] = "Tous";

        foreach ($departement as $dep) {
            $options[$dep->code_departement] = $dep->nom_departement;
        }

        echo form_dropdown('Département', $options, '1', $attrib_select);
        ?>
    </div>

    <div class="mb-3 col-md-3">
        <?php
        echo form_label('Ville :', 'ville', $att_label);
        ?>
        <div class="input-group">
            <?php
            // Création du tableau des attributs du champ login
            $data_nom = [
                'class' => 'form-control',
                'name' => 'ville',
                'id' => 'ville',
                'type' => 'text',
                'placeholder' => '',
                // à la validation du formulaire, si celui-ci n'est pas valide,
                // si le champ était rempli,
                // la saisie de l'utilisateur sera toujours présente
                'value' => set_value('ville')
            ];
            // Ajout du champ input 'ville' au formulaire
            echo form_input($data_nom);
            ?>
            <div class="input-group-append">
                <i class="bi bi-x-lg" id="clear-input" style="font-size: 150%;"></i>
            </div>
        </div>
    </div>

    <!-- le contenu de la div est alignée à gauche grace à flex -->
    <div class="col-md-3 d-flex justify-content-end">
        <?php
//création du tableau des attributs des boutons
        $att_btn = [
            'class' => 'btn btn-primary'
        ];
//ajout du bouton submit au formulaire
        echo form_submit('btn_Valider', 'Rechercher', $att_btn);
        ?>
    </div>

    <?php
    //Fermeture de formulaire
    echo form_close();
    ?>
</div>
</body>
</html>

<script>
    // Récupérer l'icône et l'input par leur ID
    const clearIcon = document.getElementById('clear-input');
    const villeInput = document.getElementById('ville');

    // Ajouter un gestionnaire d'événements au clic sur l'icône
    clearIcon.addEventListener('click', function () {
        // Effacer le contenu de l'input
        villeInput.value = '';
    });
</script>

<script type="text/javascript">

    $(function () {

        $('#listePays').change(function () { //sur l'événement change de la liste des pays
            var lepays = $(this).val(); // on récupérer la valeur du privilège choisi
            listeDepart = document.getElementById("listeDepartement");
            if (lepays === "75") {
                //listePays.removeAttribute('disabled');
                listeDepart.removeAttribute("disabled");
            } else if (!listeDepart.disabled && lepays != "75") {
                // Si la France n'est pas sélectionnée, désactive la liste des départements
                listeDepart.setAttribute('disabled', 'disabled');
            }
        });
    });


</script>