<div class="container">
    <!-- affiche le titre reçu -->
    <h1><?= esc($titre) ?></h1>
    
    <?php 
    $attributes = ["id" => "userform", "name" => "userform"];
    // Ajout du formulaire avec indication de l'action lors du submit
    // Ici appel du contrôleur ConnexionController grâce à sa route connexion
    echo form_open('connexion', $attributes);
    ?>
    
    <div class="mb-3 col-md-3">
        <?php 
        // création du tableau des attributs des labels
        $att_label = [
            'class' => 'form-label'
        ];
        echo form_label('Identifiant', 'login', $att_label);
        
        // Création du tableau des attributs du champ login
        $data_login = [
            'class' => 'form-control',
            'name' => 'login', 
            'id' => 'login',
            'type' => 'text', 
            'placeholder' => 'login',
            // à la validation du formulaire, si celui-ci n'est pas valide,
            // si le champ était rempli,
            // la saisie de l'utilisateur sera toujours présente
            'value' => set_value('login')
        ];
        // Ajout d cahmp input 'login' au formulaire
        echo form_input($data_login);
        ?>
    </div>
    <div class="mb-3 col-md-3">
        <?php 
        //ici on réutilise $att_label car les attributs des labels sont identiques
        echo form_label('Mot de passe', 'mdp', $att_label);
        
        //création du tableau des attributs du champ mdp
        $data_mdp = [
            'class' => 'form-control',
            'name' => 'mdp',
            'id' => 'mdp', 
            'placeholder' => 'mot de passe',
            'value' => set_value('mdp')
        ];
        //ajout du champ input (de type password) 'mdp' au formulaire
        //la fonction form_password() valorise l'attribut type à "password"
        echo form_password($data_mdp);
        ?>
    </div>
    <!-- le contenu de la div est alignée à gauche grace à flex -->
    <div class="col-md-3 d-flex justify-content-end">
        <?php 
        //création du tableau des attributs des boutons
        $att_btn = [
            'class' => 'btn btn-primary'
        ];
        //ajout du bouton submit au formulaire
        echo form_submit('btn_Valider', 'Se connecter', $att_btn);
        ?>
    </div>
    
    <?php 
    //Fermeture de formulaire
    echo form_close();
    ?>
</div>
</body>
</html>
