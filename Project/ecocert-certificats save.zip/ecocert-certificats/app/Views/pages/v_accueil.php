<div class="container">
    <div class="text-center">
        <h1>Organisme de contrôle & de certification</h1>
        <h2>au service de l'homme et de l'environnement</h2>
        <?php 
        
        $imageProperties = [
            'src' => img_url('accueil.jpg'),
            'alt' => 'image blé',
            'class' => 'img-thumbnail mt-4',
            'width' => '500',
            'height' => '219',
            'title' => 'image blé',
        ];
        
        echo img($imageProperties);
        ?>
    </div>
</div>
</body>
</html>
