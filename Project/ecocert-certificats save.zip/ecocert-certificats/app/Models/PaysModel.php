<?php

namespace App\Models;

use CodeIgniter\Model;

class PaysModel extends Model {

    //on indique dans la variable $table le nom de la table utilisée
    protected $table = 'pays';
    

    /**
     * retourne tous les pays qui sont dans la bdd
     * @return tous les pays qui sont dans la bdd
     */
    public function getPays() {
        $db = \Config\Database::connect();
        return $db->table($this->table)
                        ->select('id, nom_pays')
                        ->get()
                        ->getResult();
    }
    
    

}
