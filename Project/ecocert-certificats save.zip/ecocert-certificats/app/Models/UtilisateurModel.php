<?php 

namespace App\Models;

use CodeIgniter\Model;

class utilisateurModel extends Model {
    //on indique dans la variable $table le nom de la table utilisée
    protected $table = 'utilisateur';
    
    /**
     * retourne le nom et le prénom de l'utilisateur identifié
     * @param type $login login
     * @param type $mdp mot de pass
     * @return les informations de l'utilisateur si les identifiants sont corrects
     */
    public function getUtilisateur($login, $mdp) {
        $db = \Config\Database::connect();
        return $db->table($this->table)
                ->select('nomUtilisateur, prenomUtilisateur')
                ->where('login', $login)
                ->where('mdp', hash('sha512', $mdp))
                ->get()
                ->getResult();
    }
}

