<?php

namespace App\Models;

use CodeIgniter\Model;

class DepartementModel extends Model {

    //on indique dans la variable $table le nom de la table utilisée

    protected $tableD = 'departement';

    /**
     * retourne tous les departement qui sont dans la bdd
     * @return tous les departement qui sont dans la bdd
     */
    public function getDepartement() {
        $db = \Config\Database::connect();
        return $db->table($this->tableD)
                        ->select('code_departement, nom_departement')
                        ->get()
                        ->getResult();
    }
    
    /**
     * retourne tous les departement qui sont dans la bdd
     * @return tous les departement qui sont dans la bdd
     */
    public function getDepartementPays() {
        $db = \Config\Database::connect();
        return $db->table($this->tableD)
                        ->select('code_departement, nom_departement')
                        ->get()
                        ->getResult();
    }

}
