
<div class="container equipe">
    <h1>L'équipe</h1>
    <div class="row grid gap-4">
        <div class="card mb-3 p-3 col-md-6 ml-4 ml-md-0 " style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start imgp" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="dtp"><h5 class="card-title tp">Pablo Boureau</h5></div>
                        
                        <p class="card-text pct">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3 p-3 col-md-6 mr-4 mr-md-0" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start imgp" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="dtp"><h5 class="card-title tp">Pablo Boureau</h5></div>
                        <p class="card-text pct">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3 grid gap-4">
        <div class="card mb-3 p-3 col-md-6 " style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start imgp" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="dtp"><h5 class="card-title tp">Pablo Boureau</h5></div>
                        <p class="card-text pct">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3 p-3 col-md-6" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start imgp" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="dtp"><h5 class="card-title tp">Pablo Boureau</h5></div>
                        <p class="card-text pct">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-3 grid gap-4">
        <div class="card mb-3 p-3 col-md-6 " style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start imgp" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="dtp"><h5 class="card-title tp">Pablo Boureau</h5></div>
                        <p class="card-text pct">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mb-3 p-3 col-md-6" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start imgp" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="dtp"><h5 class="card-title tp">Pablo Boureau</h5></div>
                        <p class="card-text pct">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>