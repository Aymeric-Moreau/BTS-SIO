

<div class="container-fluid">

    <div class ="text-center">
        <?php
        if (isset($_SESSION['login'])) {
            include 'V_caroussel.php';
            ?>

        <?php } else {
            ?>

            <?php
            include 'V_caroussel.php';
            include 'V_card.php';
            include 'V_presentation_personne.php';
            include 'V_form.php';
            ?>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10818.62722477028!2d0.3963074999999999!3d47.32104275!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47fd311c2ee857a3%3A0x2c71615bf537172f!2sAD%20-%20Garage%20Expert%20Gu%C3%A9d%C3%A9!5e0!3m2!1sfr!2sfr!4v1686580761942!5m2!1sfr!2sfr"
                    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>




            <?php
        }
        ?>


    </div>

</div>

