

<div class="container-fluid">

    <div class ="text-center">
       
            <?php
            include 'V_introduction.php';
            
            

            include 'V_contact.php';
            ?>


    </div>

</div>

