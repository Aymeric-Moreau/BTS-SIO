 <div class="container">
     <h1>Qui somme nous ?</h1>
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="text-square">
          <h2>Texte</h2>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="image-square">
          <img src="" alt="Image 1">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="image-square">
          <img src="" alt="Image 2">
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="text-square">
          <h2>Texte</h2>
        </div>
      </div>
    </div>
  </div>