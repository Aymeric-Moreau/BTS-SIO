
<div class="container-fluid equipe">
    <h1 class="justify-content-start h1e">L'équipe</h1>
    <div class="row grid gap-4 justify-content-center">



        <div class="col-md-5">
            <div class="card cp ">
                <div class="row g-0">
                    <div class="col-4">
                        <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-8 d-flex flex-column">
                        <div class="card-body d-flex flex-column justify-content-center align-items-start titleP text-white py-3 px-4">
                            <h5 class="card-title">Prénom NOM</h5>
                        </div>
                        <div class="card-body d-flex flex-column justify-content-center align-items-start py-3 px-4 flex-grow-1">
                            <p class="card-text">‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎  </p>
                            <p class="card-text">‎ ‎ ‎ ‎ ‎  </p>

                            <p class="card-text">‎ ‎ ‎ ‎ ‎ ‎ </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card cp ">
                <div class="row g-0">
                    <div class="col-4">
                        <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-8 d-flex flex-column">
                        <div class="card-body d-flex flex-column justify-content-center align-items-start titleP text-white py-3 px-4">
                            <h5 class="card-title">Prénom NOM</h5>
                        </div>
                        <div class="card-body d-flex flex-column justify-content-center align-items-start py-3 px-4 flex-grow-1">
                            <p class="card-text">12345678912345678912345678912345678912345 </p>
                            <p class="card-text">2122232425262728293031323334353</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card cp ">
                <div class="row g-0">
                    <div class="col-4">
                        <img src="assets/img/IMG.png" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-8 d-flex flex-column">
                        <div class="card-body d-flex flex-column justify-content-center align-items-start titleP text-white py-3 px-4">
                            <h5 class="card-title">Prénom NOM</h5>
                        </div>
                        <div class="card-body d-flex flex-column justify-content-center align-items-start py-3 px-4 flex-grow-1">
                            <p class="card-text">1
                            </p>
                            <p class="card-text">2
                            </p>
                                                        <p class="card-text">3
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card cp">
                <div class="row g-0">
                    <div class="col-4">
                        <img src="assets/img/portrait_chad.png" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-8 d-flex flex-column">
                        <div class="card-body d-flex flex-column justify-content-start align-items-start titleP text-white py-3 px-4">
                            <h5 class="card-title">Prénom NOM</h5>
                        </div>
                        <div class="card-body d-flex flex-column justify-content-center align-items-start py-3 px-4 flex-grow-1">
                            <p class="card-text">1
                            </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
